package com.unab.main;
import com.unab.clases.Gato;

public class Main {

	public static void mostrarTablero(char[][] tablero) {
		System.out.println(tablero.length);
		for (int i = 0; i < filas; i++) { //filas 
			for (int j=0; j < columnas; j++) { // columnas
				System.out.print(tablero[i][j]);
			}
			System.out.println("");
		}
	
	
	public static void main(String[] args) {
		
		//instancia de juego
		
		Gato partida = new Gato(); // debemos importarlo
		
		
		
	}

}
