package com.unab.clases;

public class Gato extends Juego{

	
	private char[] simbolos = new char [cantJugadores];
	
	
	public Gato() {
		super("Gato",2,3,3);
		simbolos[0] = 'x';
		simbolos[1] = 'o';
		for (int i = 0; i < filas; i++) { //filas 
			for (int j=0; j<columnas; j++) { // columnas
				tablero[i][j] = '*';
			}
		}
	}
	

	
	
	
}
