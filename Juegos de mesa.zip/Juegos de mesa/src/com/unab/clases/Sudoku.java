package com.unab.clases;

public class Sudoku extends Juego{

	
	private int nivel;
	//private int cantidadFilas;
	//private int cantidadColumnas;
	

	
	public Sudoku() {
		super("Sudoku", 1, 6, 6);
	}
	
	
}
